var correctas = new Array("B", "C", "D", "D", "A", "C", "D", "A", "D", "A", "D", "C");

function responder(matriz){
	var respcorrec=0;
	var respmal=0;
	var respues= document.getElementById('respuestas');

	respues.style.backgroundColor= "#1E88E5";
	respues.style.marginLeft= "10%";
	respues.style.marginRigth= "10%";
	respues.style.marginTop= "0%";
	respues.style.marginBottom= "5%";
	respues.style.width= "80%";
	respues.style.padding= "50px";
	respues.style.color= "white";
	respues.style.borderRadius= "5px";

	var mostrar= "";

	for(var i=0; i<matriz.length;i++){
		var radios= document.getElementsByName(i+1);
		for(j=0;j<radios.length;j++){
			if(radios[j].checked){
				var valor= radios[j].value;
				if(valor==matriz[i]){
					respcorrec++;
					break; 
				}else{
					respmal++;
					break;
				}
			}
		}
	}

	var nulas= matriz.length - (respcorrec + respmal);
	respmal+= nulas;

	var notasFin= (respcorrec/matriz.length)*10;

	mostrar+= "<p>Respuestas correctas: "+respcorrec+ "</p>";
	mostrar+= "<p>Respuestas incorrectas: "+respmal+ "</p><br>";

	mostrar+= "<p>Su nota es: "+notasFin+"</p>";

	respues.innerHTML= mostrar;
}
