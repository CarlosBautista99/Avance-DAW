var i=0;

function contador(){
	i += 1;
}

function agregar(){
	contador();

	var br= document.createElement("br");
	var br2= document.createElement("br");
	var br3= document.createElement("br");
	var br4= document.createElement("br");
	var br5= document.createElement("br");
	var br6= document.createElement("br");
	var br7= document.createElement("br");
	var br8= document.createElement("br");
	var br9= document.createElement("br");
	var br10= document.createElement("br");
	var br11= document.createElement("br");
	
	//crea div contenedor
	var a= document.createElement("div");
	a.setAttribute("id", "Pregu"+i);

	//crea label de ingreso de pregunrta
	var b= document.createElement("label");
	var c= document.createTextNode((i+1)+". Ingrese la pregunta:");
	b.appendChild(c);

	//crea textarea para pregunta
	var d= document.createElement("textarea");
	d.setAttribute("id", "pregunta"+i);
	d.setAttribute("name", "pregunta"+i);
	d.setAttribute("rows","2");
	d.setAttribute("cols","25");
	d.setAttribute("class","pregunta");

	//crea label para ingreso de tiempo
	var e= document.createElement("label");
	var f= document.createTextNode("Seleccione el tiempo de la pregunta: ");
	e.appendChild(f);

	//crea radiob de 10s
	var g= document.createElement("input");name="tiempo"
	g.setAttribute("type", "radio");
	g.setAttribute("name", "tiempo");
	g.setAttribute("id", "tiempo1"+i);
	g.setAttribute("value", "10")

	var h= document.createElement("label");
	var j= document.createTextNode("10 seg");
	h.appendChild(j);

	//crea radiob de 20s
	var k= document.createElement("input");
	k.setAttribute("type", "radio");
	k.setAttribute("name", "tiempo");
	k.setAttribute("id", "tiempo2"+i);
	k.setAttribute("value", "20")

	var l= document.createElement("label");
	var m= document.createTextNode("20 seg");
	l.appendChild(m);

	//crea radiob de 30s
	var n= document.createElement("input");
	n.setAttribute("type", "radio");
	n.setAttribute("name", "tiempo");
	n.setAttribute("id", "tiempo3"+i);
	n.setAttribute("value", "30")

	var o= document.createElement("label");
	var p= document.createTextNode("30 seg");
	o.appendChild(p);

	//poner imagen
	var img= document.createElement("div");
	img.setAttribute("id", "divFileUpload");

	var selimg= document.createElement("input");
	selimg.setAttribute("id", "file-upload");
	selimg.setAttribute("type", "file");
	selimg.setAttribute("accept", "image/*");

	img.appendChild(selimg);

	var verimg= document.createElement("div");
	verimg.setAttribute("id", "file-preview-zone");

	//crea label de respuesta
	var q= document.createElement("label");
	var r= document.createTextNode("Ingrese las respuestas:");
	q.appendChild(r);

	//crea lable y textarea de rspuesta a
	var s= document.createElement("label");
	var t= document.createTextNode("A. ");
	s.appendChild(t);

	var u= document.createElement("textarea");
	u.setAttribute("id", "resp1"+i);
	u.setAttribute("cols", "20");
	u.setAttribute("rows", "1");

	//crea lable y textarea de rspuesta b
	var v= document.createElement("label");
	var w= document.createTextNode("B. ");
	v.appendChild(w);

	var x= document.createElement("textarea");
	x.setAttribute("id", "resp2"+i);
	x.setAttribute("cols", "20");
	x.setAttribute("rows", "1");

	//crea lable y textarea de rspuesta c
	var y= document.createElement("label");
	var z= document.createTextNode("C. ");
	y.appendChild(z);

	var aa= document.createElement("textarea");
	aa.setAttribute("id", "resp3"+i);
	aa.setAttribute("cols", "20");
	aa.setAttribute("rows", "1");

	//crea lable y textarea de rspuesta d
	var bb= document.createElement("label");
	var cc= document.createTextNode("D. ");
	bb.appendChild(cc);

	var dd= document.createElement("textarea");
	dd.setAttribute("id", "resp4"+i);
	dd.setAttribute("cols", "20");
	dd.setAttribute("rows", "1");

	//crea label y textbox de resp correcta
	var ee= document.createElement("label");
	var ff= document.createTextNode("Respuesta correcta: ");
	ee.appendChild(ff);

	var gg= document.createElement("input");
	gg.setAttribute("type", "text");
	gg.setAttribute("id", "correc"+i);

	//crea linea
	var hr= document.createElement("hr");
	hr.setAttribute("color", "black");

	a.appendChild(b);
	a.appendChild(br);
	a.appendChild(d);
	a.appendChild(br2);
	a.appendChild(br9);
	a.appendChild(e);
	a.appendChild(g);
	a.appendChild(h);
	a.appendChild(k);
	a.appendChild(l);
	a.appendChild(n);
	a.appendChild(o);
	a.appendChild(br3);
	a.appendChild(br10);

	a.appendChild(img);
	a.appendChild(verimg);

	a.appendChild(q);
	a.appendChild(br4);
	a.appendChild(s);
	a.appendChild(u);
	a.appendChild(br5);
	a.appendChild(v);
	a.appendChild(x);
	a.appendChild(br6);
	a.appendChild(y);
	a.appendChild(aa);
	a.appendChild(br7);
	a.appendChild(bb);
	a.appendChild(dd);
	a.appendChild(br8);
	a.appendChild(ee);
	a.appendChild(gg);
	a.appendChild(hr);

	document.getElementById("crearPreg").appendChild(a);


}

function enviar(){
	alert("Sus preguntas han sida guardadas exitosamente");
	document.location.href="Principal.html";
}

//Subir imagenes
function readFile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
 
            reader.onload = function (e) {
                var filePreview = document.createElement('img');
                filePreview.id = 'file-preview';
                //e.target.result contents the base64 data from the image uploaded
                filePreview.src = e.target.result;
                console.log(e.target.result);
 
                var previewZone = document.getElementById('file-preview-zone');
                previewZone.appendChild(filePreview);
            }
 
            reader.readAsDataURL(input.files[0]);
        }
}
 
var fileUpload = document.getElementById('file-upload');
    
fileUpload.onchange = function (e) {
    readFile(e.srcElement);
}
