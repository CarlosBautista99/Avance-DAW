function entrarInicio(){
  var user= document.getElementById("usuario").value;
  var contra= document.getElementById("contra").value;

  if(user== "profesor123" && contra== "12345"){
    document.location.href="Principal.html";
  }
  else if(user== "estudiante123" && contra== "67890"){
  	document.location.href="estudiante.html";
  }
  else{
  	var alerta= document.getElementById("alerta");
  	alerta.innerHTML= "<p  class= 'alert alert-danger' role= 'alert'>El usuario no esta registrado</p>";
  }
  
}

